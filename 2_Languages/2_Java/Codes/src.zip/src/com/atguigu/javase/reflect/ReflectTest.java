package com.atguigu.javase.reflect;

import org.junit.Test;

class Teacher {

    public String name;
    public int age;
    public String gender;

    public Teacher() {
    }

    public Teacher(String name, int age, String gender) {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    @Override
    public String toString() {
        return "Teacher{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", gender='" + gender + '\'' +
                '}';
    }
}

public class ReflectTest {
    // 写一个Student类, 用反射的方式创建对象, 并打印输出
    @Test
    public void test2() {
        // 干预类的加载
        //Class clazz = Class.forName("类的全限定名称"); // 结果就是类模板对象
        try {
            // 手工加载类模板, 结果就是获取到了类模板对象, 根据类名加载类模板. 动态加载类
            Class clazz = Class.forName("com.atguigu.javase.reflect.Teacher"); // 结果就是类模板对象
            // 依据类模板创建对象, 通过方法来创建, 像工厂, 调用了无参构造器创建对象.
            Object object1 = clazz.newInstance(); // clazz是Teacher类模板, 所以创建出来的对象就是Teacher对象
            System.out.println(object1);
            Object object2 = clazz.newInstance();
            System.out.println(object2);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test1() {
        Teacher t1 = new Teacher();// 构造方法
        t1.name = "佟刚";
        t1.age = 40;
        t1.gender = "男";

        System.out.println(t1.name);
        System.out.println(t1.age);
        System.out.println(t1.gender);

        System.out.println(t1);

        Teacher t2 = new Teacher("宁姐", 20, "女");
        System.out.println(t2);

    }
}
