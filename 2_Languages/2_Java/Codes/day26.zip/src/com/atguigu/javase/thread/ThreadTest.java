package com.atguigu.javase.thread;

import javafx.concurrent.Task;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

/**
 * 如何创建并启动一个线程?
 * 	1) 实现方式
 * 		1) 写一个类实现Runnable并实现 run
 * 		2) 创建这个类的对象,并以它为实参, 创建线程对象
 * 		3) 调用线程对象的.start()
 *
 * 	2) 继承方式
 * 		1) 写一个类继承Thread, 并重写run
 * 		2) 创建这个类对象, 相当于创建了线程对象
 * 		3) 调用线程对象的.start()
 *
 * 3) 实现Callable接口, 对Runnable接口的补充
 *      1) 写一个具体类实现 Callable接口, 并实现方法call
 *      2) 创建一个FutureTask对象, 关联Callable, 因为它也实现Runnable, 相当于Runnable对象
 *      3) 再以FutureTast对象为实参, 创建Thread对象
 *      4) 调用Thread对象的start()
 *
 * 4) 使用线程池 : 统一调度线程的创建和使用. Executor, ExecutorService
 *      1) 写一个具体类实现Callable接口, 实现call()
 *      2) 创建线程池, 通过工具类Executors.newXXx
 *      3) 把具体的Callable对象提交给线程池, 并获取相应的task对象, 用于获取将来的值
 *      4) 调用线程池的shutdown方法.
 *      5) 依次从task对象中获取到将来的值.
 *
 */
class MyCall implements Callable<String> {
    @Override
    public String call() throws Exception {
        for (int i = 0; i < 300; i++) {
            System.out.println(Thread.currentThread().getName() + " : " + i);
        }
        return Thread.currentThread().getName();
    }
}
public class ThreadTest {

    public static void main(String[] args) {
        MyCall myCall = new MyCall();
        //ExecutorService executorService = Executors.newCachedThreadPool();// 自动缓冲的线程池, 提交多少就创建多少
        ExecutorService executorService = Executors.newFixedThreadPool(30);// 固定个数的线程池, 不太好用
        //ExecutorService executorService = Executors.newWorkStealingPool();// 工作窃取线程池, 最好用的.
        List<Future<String>> list = new ArrayList<>();
        for (int i = 0; i < 300; i++) {
            Future<String> task = executorService.submit(myCall);
            list.add(task);
        }
        executorService.shutdown(); // 如果忘了它, 线程池还一直在运行中..... 在这里是提交结束的意思.
        while (list.size() > 0) {
            System.out.println("list元素个数 : " + list.size());
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i).isDone()) { // 先判断此任务是否完成, 提高观察效率
                    System.out.println(list.get(i) + " is done. .........................");
                    try {
                        System.out.println("将来的值 : " + list.get(i).get());
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    }
                    list.remove(i);
                    break;
                }
            }
        }
    }

    public static void main3(String[] args) {
        MyCall myCall = new MyCall();
        ExecutorService executorService = Executors.newCachedThreadPool();// 自动缓冲的线程池
        Future<String> task1 = executorService.submit(myCall); // 一旦提交它, 就会在内部分配线程并执行此callalbe, 并把用于获取返回值的task对象返回
        Future<String> task2 = executorService.submit(myCall);
        Future<String> task3 = executorService.submit(myCall);

        try {
            System.out.println("将来的值 : " + task1.get());
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

        try {
            System.out.println("将来的值 : " + task2.get());
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

        try {
            System.out.println("将来的值 : " + task3.get());
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }

    public static void main2(String[] args) {
        MyCall myCall = new MyCall();
        FutureTask<String> task = new FutureTask<>(myCall); // FutureTask实现了FutureRunnable接口.
        Thread thread = new Thread(task);
        thread.start();
        for (int i = 0; i < 300; i++) {
            System.out.println("main : " + i);
        }
        try {
            String s = task.get();// 获取将来的返回值, 此方法会引起当前线程阻塞, 要等待子线程结束后才返回.
            System.out.println("获取到的将来的值 : " + s);
        } catch (InterruptedException e) { // 子线程被打断
            e.printStackTrace();
        } catch (ExecutionException e) { // 如果在call方法中出现异常
            e.printStackTrace();
        }
    }
}
