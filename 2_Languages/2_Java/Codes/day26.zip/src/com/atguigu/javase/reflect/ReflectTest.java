package com.atguigu.javase.reflect;

import org.junit.Test;

import java.io.InputStream;
import java.io.Serializable;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Properties;
import java.util.concurrent.Callable;

/**
 * 反射 : 先获取到类模板, 再从类模板展开, 进一步使用对象.
 *
 * 获取类模板对象的方式 :
 *      1) 已知类, 使用类的静态属性.class来获取, 这种方式最安全,高效..  属于硬编码
 *          Class clazz = Teacher.class;
 *          String.class, int.class, double.class,
 *
 *      2) 已经对象, 通过对象的getClass()获取相应的类模板对象. 安全,高效, 硬编码
 *          Class clazz = new Teacher().getClass();
 *
 *      3) Class clazz = Class.forName("类的全限定名称"); 这是反射的基础, 属性软编码
 *
 *      4) 通过类加载器对象.loadClass("类的全限定名称")
 *          Class clazz = this.getClass().getClassLoader().loadClass("类的全名");
 */
@Retention(RetentionPolicy.RUNTIME) // 停留期必须到运行时..
@interface MyAnnotation {
    int id() default 10;
    String value() default "缺省值";
}

@MyAnnotation("我是一个值")
class Teacher extends ArrayList implements Runnable, Serializable, Callable {

    public static String school = "atguigu";

    public static void test() {
        System.out.println("我是静态方法");
    }

    private String name;
    private int age;
    private String gender;

    public Teacher() {
    }

    public Teacher(String name, int age, String gender) {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    @Override
    public String toString() {
        return "Teacher{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", gender='" + gender + '\'' +
                '}';
    }

    @Override
    public void run() {

    }

    @Override
    public Object call() throws Exception {
        return null;
    }

    public void lesson() {
    }

    private void lesson(String content, int hours) {
        System.out.println(name + " 老师在上[" + content + "]课, 共上了[" + hours + "]小时");
        throw new Error("我是一个无端的错误");
        //return "上课OK";
    }
}

public class ReflectTest {

    @Test
    public void test12() throws Exception {
        Class clazz = Class.forName("com.atguigu.javase.reflect.Teacher");
        // 只能反射能处理注解, 并且注解必须停留到Runtime
        MyAnnotation annotation = (MyAnnotation)clazz.getAnnotation(MyAnnotation.class);
        System.out.println(annotation);
    }

    @Test
    public void test11() throws Exception {
        // 静态成员的访问不需要this目标对象.
        Class clazz = Class.forName("com.atguigu.javase.reflect.Teacher");
        Field school = clazz.getField("school");
        Object o = school.get(null); // ? 会不会抛出空指针 ?? 静态属性的访问完全忽略参数
        System.out.println(o);
        Method test = clazz.getMethod("test");
        test.invoke(null);
    }

    @Test
    public void test10() {
        try {
            Class clazz = Class.forName("com.atguigu.javase.reflect.Teacher");
            Object object = clazz.newInstance();
            // getMethod获取的是本类及从父类继承的所有公共方法
            //Method method = clazz.getMethod("lesson", String.class, int.class);
            // getDeclaredMethod可以获取本类声明的任意方法, 包括私有的.
            Method method = clazz.getDeclaredMethod("lesson", String.class, int.class);
            method.setAccessible(true); // 突破封装
            Object ret = method.invoke(object, "MyBatis", (short)5);
            //System.out.println(ret);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) { // 访问私有成员
            e.printStackTrace();
        } catch (InstantiationException e) { // 创建对象时出异常
            e.printStackTrace();
        } catch (NoSuchMethodException e) { // 方法定位失败
            e.printStackTrace();
        } catch (InvocationTargetException e) {// 调用的目标方法出现异常时
            e.printStackTrace();
        }
    }

    @Test
    public void test9() {
        try {
            Class clazz = Class.forName("com.atguigu.javase.reflect.Teacher");
            //Object o = clazz.newInstance(); // 没有无参构造器时出错
            //public Teacher(String name, int age, String gender) {
            Constructor constructor = clazz.getConstructor(Class.forName("java.lang.String"), int.class, String.class);// 形参类型列表
            Object obj = constructor.newInstance("佟刚", 40, "男"); // 需要实参列表
            System.out.println(obj);
            // 先获取方法对象, 再配合目标this
            //public String lesson(String content, int hours) {
            Method lessonMethod = clazz.getMethod("lesson", String.class, int.class );// 第一个参数是方法名, 后面是形参类型列表
            Object retValue = lessonMethod.invoke(obj, "JavaWEB", 3);//等效于 obj.lesson("javaWeb", 3);
            System.out.println(retValue); // 如果实际调用的方法没有返回值, 这里的返回值就是null

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test8() throws Exception {
        // 加载类路径中的资源文件 classpath
        InputStream input = this.getClass().getClassLoader().getResourceAsStream("com/sun/corba/se/impl/logging/LogStrings.properties");
        Properties properties = new Properties();
        properties.load(input);

        Enumeration<?> enumeration = properties.propertyNames();
        while (enumeration.hasMoreElements()) {
            Object name = enumeration.nextElement();
            Object value = properties.get(name);
            System.out.println(name + " >>>>>>>>>>>>>> " + value);
        }
    }

    @Test
    public void test7() throws Exception {
        // 最底层的是BootstrapClassLoader是由C++编写,负责最核心 的类的加载, 包括的就是JDK/jre/lib目录下的jar文件的加载
        // BootstrapClassLoader的上层是扩展类ExtClassLoader, 负责加载JDK/jre/lib/ext目录中的jar
        // ExtClassLoader的上层是系统类加载或应用程序类加载器, 负责加载 -classpath环境变量中的类, 包括导入的jar和src目录

        // 双亲委派 : 系统类加载器会把所有类加载的任务先委派扩展类加载器和引导类加载器
        // 扩展类加载器和引导类加载器发现此类不该我加载, 拒绝, 请求驳回, 最后由系统类加载器加载
        // 如果要加载的类是核心敏感类, 双亲当仁不让, 直接加载, 系统类加载器就不加了.
        ClassLoader classLoader1 = ClassLoader.getSystemClassLoader();
        System.out.println(classLoader1);
        ClassLoader classLoader2 = classLoader1.getParent();
        System.out.println(classLoader2);
        ClassLoader classLoader3 = classLoader2.getParent();// 获取引导类加载器
        System.out.println(classLoader3);

        ClassLoader classLoader = Teacher.class.getClassLoader();
        System.out.println(classLoader);

        ClassLoader classLoader4 = String.class.getClassLoader(); // 引导类加载器加载
        System.out.println(classLoader4);
    }

    @Test
    public void test6() throws Exception {
        Class clazzI = Integer.class;
        Class clazzi = int.class; // 只要是数据类型, 一定有相应的类模板对象.
        System.out.println(clazzI == clazzi); // 包装类型和基本类型不是同一类型
        //clazzi.newInstance(); // 什么都不能做, 唯一能做的事情就是作为一个标识, 表明它是int类型
        System.out.println(clazzi.isPrimitive()); // 判断类模板表示的类型是否是基本型
        System.out.println(clazzI.isPrimitive());

        System.out.println("**************************************************");

        Class clazz1 = Teacher.class;
        Class clazz2 = new Teacher("a", 2, "b").getClass();
        System.out.println(clazz1 == clazz2);
        Class clazz3 = Class.forName("com.atguigu.javase.reflect.Teacher");
        System.out.println(clazz1 == clazz3);
        ClassLoader classLoader = this.getClass().getClassLoader(); // 了解
        Class clazz4 = classLoader.loadClass("com.atguigu.javase.reflect.Teacher");
        System.out.println(clazz3 == clazz4);
    }

    @Test
    public void test5() throws Exception {
        // 有了类模板, 可以获取和这个类相关的所有信息
        Class<?> clazz = Class.forName("com.atguigu.javase.reflect.Teacher");
        Class<?> superclass = clazz.getSuperclass();// 获取父类类型
        System.out.println(superclass);

        Class<?>[] interfaces = clazz.getInterfaces();// 获取实现的所有接口
        for (int i = 0; i < interfaces.length; i++) {
            System.out.println(interfaces[i]);
        }

        ClassLoader classLoader = clazz.getClassLoader();// 当前加载类模板的类加器对象
        System.out.println(classLoader);
    }

    @Test
    public void test4() {
        try {
            Class clazz = Class.forName("com.atguigu.javase.reflect.Teacher");
            Object object1 = clazz.newInstance();
            System.out.println(object1);
            // getField无法获取私有属性定义, 其实它只能获取公共的属性定义, 包括本类的和父类继承的.
            //Field nameField = clazz.getField("name");
            Field nameField = clazz.getDeclaredField("name"); // 获取本类中声明的任意属性, 当然也包括私有的.
            nameField.setAccessible(true); // 设置为可访问, 就可以访问了. 暴力反射!!! 强烈不建议. 突破封装性.
            nameField.set(object1, "佟刚");

            Field ageField = clazz.getDeclaredField("age");
            ageField.setAccessible(true);
            ageField.set(object1, 40);

            Field genderField = clazz.getDeclaredField("gender");
            genderField.setAccessible(true);
            genderField.set(object1, "男");

            System.out.println(object1);
        } catch (ClassNotFoundException e) { // 类名错误或类真的不存在
            e.printStackTrace();
        } catch (IllegalAccessException e) { // 访问了没有访问权限的成员. 比如访问了私有成员.
            e.printStackTrace();
        } catch (InstantiationException e) { // 在创建对象时构造器定位失败.
            e.printStackTrace();
        } catch (NoSuchFieldException e) { // 查找属性定义时, 属性名错误或属性定义不存在
            e.printStackTrace();
        }
    }

    @Test
    public void test3() {
        try {
            Class clazz = Class.forName("com.atguigu.javase.reflect.Teacher");
            Object object1 = clazz.newInstance();
            System.out.println(object1);
            //((Teacher)object1).name = "佟刚"; // 之前的方式
            // 先找到属性定义对象, 再配合this对象, 完成属性访问
            Field nameField = clazz.getField("name"); // Field就是属性定义对象
            nameField.set(object1, "佟刚"); // object1.name = "佟刚", 对象属性必须配合this对象, 才能完成访问
            System.out.println(nameField.get(object1)); // 获取属性值 System.out.println(object1.name);
            Field ageField = clazz.getField("age");
            ageField.set(object1, 40);// 修改age属性
            Field genderField = clazz.getField("gender");// 修改gender属性
            genderField.set(object1, "男"); // object.gender = "男"
            System.out.println(object1);

            Object object2 = clazz.newInstance();
            // 属性定义就一个
            nameField.set(object2, "宁姐"); //object2.name = "宁姐";
            ageField.set(object2, 20);
            genderField.set(object2, "女");
            System.out.println(object2);
        } catch (ClassNotFoundException e) { // 类名错误或类真的不存在
            e.printStackTrace();
        } catch (IllegalAccessException e) { // 访问了没有访问权限的成员. 比如访问了私有成员.
            e.printStackTrace();
        } catch (InstantiationException e) { // 在创建对象时构造器定位失败.
            e.printStackTrace();
        } catch (NoSuchFieldException e) { // 查找属性定义时, 属性名错误或属性定义不存在
            e.printStackTrace();
        }
    }

    @Test
    public void test2() {
        // 干预类的加载
        //Class clazz = Class.forName("类的全限定名称"); // 结果就是类模板对象
        try {
            // 手工加载类模板, 结果就是获取到了类模板对象, 根据类名加载类模板. 动态加载类
            // 编译时不检查, 运行时出问题, 推迟到了运行时, 称为软编码, 类的提供的时机可以延迟到运行时.
            Class clazz = Class.forName("com.atguigu.javase.reflect.Teacher"); // 结果就是类模板对象, 参数中的类名必须全限定
            // 依据类模板创建对象, 通过方法来创建, 像工厂, 调用了无参构造器创建对象.
            Object object1 = clazz.newInstance(); // clazz是Teacher类模板, 所以创建出来的对象就是Teacher对象
            System.out.println(object1);
        } catch (ClassNotFoundException e) { // 类名错误或类真的不存在
            e.printStackTrace();
        } catch (IllegalAccessException e) { // 访问了没有访问权限的成员. 比如访问了私有成员.
            e.printStackTrace();
        } catch (InstantiationException e) { // 在创建对象时构造器定位失败.
            e.printStackTrace();
        }
    }

    @Test
    public void test1() {

        //Teacher t1 = new Teacher();// 无参构造方法, 问题暴露在编译时, 对Teacher是一种强依赖, 硬编码..
        //t1.name = "佟刚"; // set
        //t1.age = 40;
        //t1.gender = "男";
        //System.out.println(t1.name); // get
        //System.out.println(t1.age);
        //System.out.println(t1.gender);
        //System.out.println(t1);

        Teacher t2 = new Teacher("宁姐", 20, "女");
        System.out.println(t2);

    }
}
