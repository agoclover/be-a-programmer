package com.atguigu.javase.thread;

public class BankTest {

    public static void main(String[] args) {
        Account account = new Account("张三", 0);

        Runnable runner1 = new Withdraw(account);
        Thread thread1 = new Thread(runner1);
        thread1.setName("取钱线程1");

        Runnable runner2 = new Deposit(account);
        Thread thread2 = new Thread(runner2);
        thread2.setName("存钱线程1");

        thread1.start();
        thread2.start();

    }
}
