package com.atguigu.javase.thread;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class CallableExer {

    public static void main(String[] args) throws ExecutionException, InterruptedException {
        //* 1) 写一个具体类实现Callable接口, 实现call()
        Callable<Integer> callable = new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                int max = 0x80000000;
                for (int i = 0; i < 100; i++) {
                    int rand = (int) (Math.random() * 1000);
                    System.out.println(Thread.currentThread().getName() + " : " + rand);
                    if (rand > max) {
                        max = rand;
                    }
                }
                return max;
            }
        };
        //*  2) 创建线程池, 通过工具类Executors.newXXx
        ExecutorService executorService = Executors.newCachedThreadPool();
        //* 3) 把具体的Callable对象提交给线程池, 并获取相应的task对象, 用于获取将来的值
        List<Future<Integer>> list = new ArrayList<>(); // 保存所有furture对象
        for (int i = 0; i < 10; i++) { // 一次性提交多个任务
            Future<Integer> future = executorService.submit(callable); // 会把任务提交给线程池.
            list.add(future);
        }
        //* 4) 调用线程池的shutdown方法.
        executorService.shutdown(); // 发出通知, 线程池不再添加新任务了, 执行完当前所有任务后就结束
        //* 5) 依次从task对象中获取到将来的值.
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i).get());
        }

        /*
        while (list.size() > 0) { // 任务列表如果不为空, 一直找已经完成的任务
            for (int i = 0; i < list.size(); i++) { // 从当前任务列表中遍历, 找出第一个已经完成的.
                if (list.get(i).isDone()) { // 遍历的作用是优先取已经完成的任务.
                    System.out.println("将来的值 : " + list.get(i).get()); // 直接获取结果, 不需要等待.
                    list.remove(i); // 减少任务列表
                    break;
                }
            }
        }*/
    }

    public static void main2(String[] args) {
        Callable<Integer> callable = new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                int max = 0x80000000;
                for (int i = 0; i < 100; i++) {
                    int rand = (int) (Math.random() * 1000);
                    System.out.println(Thread.currentThread().getName() + " : " + rand);
                    if (rand > max) {
                        max = rand;
                    }
                }
                return max;
            }
        };
        FutureTask<Integer> integerFutureTask = new FutureTask<>(callable);
        Thread thread = new Thread(integerFutureTask);
        thread.start();

        Integer integer = null;
        try {
            integer = integerFutureTask.get();
            System.out.println("将来的值 : " + integer);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }
}
